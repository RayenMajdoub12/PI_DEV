/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package gymgeekss.Gymgeekss.service;

import gymgeekss.Gymgeekss.Entities.commentaire;
import gymgeekss.Gymgeekss.service.commEvI;
import gymgeekss.Gymgeekss.service.commServices;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import gymgeekss.Gymgeekss.Utils.MyConnection;

/**
 *
 * @author lv
 */
public class commServices extends commEvI{
 private final Connection c = MyConnection.getInstance().getConnection();
    @Override
    public void AjouterComm(commentaire e) {
            

       PreparedStatement st;
        String query="insert into com_event (commentaire,idEvenement) values(?,?)";
        try {
            st= c.prepareStatement(query);
           
            st.setString(1,e.getComm());
            
           // st.setInt(2,e.getUserId());
            st.setInt(2,e.getIdEv());
            st.executeUpdate();
            System.out.println("Ajout accompli avec succés");
           
        } 
         catch (SQLException ex) {
           System.out.println("erreur lors de l'ajout du commtaire " + ex.getMessage());
        } }

    @Override
    public List<commentaire> AfficherAllComm( ) {
       List<commentaire> Ann= new ArrayList<>();
        String query="select  commentaire from  com_event ";
        try {
            Statement st=c.createStatement();
            ResultSet rs =st.executeQuery(query);
            while(rs.next())
            {
                commentaire A=new commentaire();
            
                 A.setComm(rs.getString(1));
               
               
             
                Ann.add(A);
            }
            return Ann;
        } 
        catch (SQLException ex) {
             System.out.println("erreur lors de l'affichage de tous les commentaires! " + ex.getMessage());
        }
        return null;  }

 
   
}
