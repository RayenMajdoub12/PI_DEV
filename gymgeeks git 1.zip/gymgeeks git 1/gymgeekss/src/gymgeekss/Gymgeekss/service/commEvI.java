/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package gymgeekss.Gymgeekss.service;

import gymgeekss.Gymgeekss.Entities.commentaire;
import java.util.List;

/**
 *
 * @author molka
 */
public abstract class commEvI {
     public abstract void AjouterComm(commentaire a);
    public abstract List<commentaire> AfficherAllComm();
}
